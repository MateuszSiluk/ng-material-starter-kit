import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { UniversityListComponent } from './components/university-list/university-list.component';
import { ProductListComponent } from './components/product-list/product-list.component';
import { UniversityListComponentModule } from './components/university-list/university-list.component-module';
import { ProductListComponentModule } from './components/product-list/product-list.component-module';

@NgModule({
  imports: [
    RouterModule.forRoot([
      { path: 'a', component: UniversityListComponent },
      { path: '', component: ProductListComponent },
    ]),
    UniversityListComponentModule,
    ProductListComponentModule,
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
